<?php
date_default_timezone_set('Asia/Shanghai');

?>
<script type="text/javascript">
　　window.location.href="<?php echo admin_url('/users.php'); ?>";
</script>